<?php
include("config.php");
error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link type="text/css" href="style.css" rel="stylesheet" />
<meta http-equiv="Content-Type" content="width=device-width, initial-scale=1" content="text/html; charset=utf-8" />
<script src="js/jquery.min.js"></script>
<script src="js/jquery-1.10.2.js"></script>
<script src="js/mjquery-ui.js"></script>
<script type="text/javascript" src="js/jquery.ptTimeSelect.js"></script>
<link rel="stylesheet" href="mjquery-ui.css">

<link rel="stylesheet" type="text/css" href="jquery.ptTimeSelect.css" />
<script type="text/javascript">
$(document).ready(function(){
	
	$('#cal').datepicker({ dateFormat: "yy-mm-dd" });

	
  	});			
 </script>
<title>Employee</title>
</head>
<body>
<div class="head">
<a href="index.php" class="aa" >Add Employee</a>
<a href="view_emp.php" class="aa">View Employee</a>
</div>
<h2><center><br />Add Employee</center></h2><br />

<form enctype="multipart/form-data" method="post">


  <div class="container">
  
    <label><b>Name</b></label>
    <input type="text" placeholder="Enter Employee name" name="name" required>
    
	<label><b>Email</b></label>
    <input type="email" placeholder="Enter Email Address" name="email" required>
    
    <label><b>Contact Number</b></label>
    <input type="text" placeholder="Enter Contact Number" name="phone" required>
    
   
    <label><b>Date Of Birth</b></label>
<input type="text" name="txt_cal" id="cal">
    
    <label><b>Post</b></label>
    <select name="post">
	<option value="HOD">HOD</option>
    <option value="PROFESSER">PROFESSER</option>
    <option value="ASSISTENT PROFESSER">ASSISTENT PROFESSER</option>
    </select>
    
    <label><b>Department</b></label>
    <select name="department">
	<option value="BCA">BCA</option>
    <option value="BBA">BBA</option>
    <option value="MCA">MCA</option>
    <option value="MBA">MBA</option>
    <option value="MSC.IT.">MSC.IT.</option>
    <option value="PGDCA">PGDCA</option>
    </select>
    
    <label><b>Qualification</b></label>
    <input type="text" placeholder="Enter Employee Qualification" name="qualification" required>
    
    <label><b>Salary</b></label>
    <input type="text" placeholder="Enter Employee Salary" name="salary" required>
    
    <label><b>Gender</b></label><br />
      <input type="radio" class="radio1" name="gender" value="Female">Female<br />
      <input type="radio" name="gender" class="radio1" value="Male">Male<br />
    </label>
    
    <label><b>Address</b></label>
    <textarea name="address" placeholder="Enter Adddress"></textarea>
    
    <br /><label>
      <input type="checkbox" name="experience" value="yes"> Experience
    </label>
    
    
    <input type="submit" name="add_emp" value="Add Employee Details">
</div>
</form></div>
  <?php
$count=0;
if(isset($_REQUEST["add_emp"]))
{	
	$nm=$_REQUEST["name"];
	$em=$_REQUEST["email"];
	$ph=$_REQUEST["phone"];
	$dob=$_REQUEST["txt_cal"];
	$e=$_REQUEST["experience"];
	$post=$_REQUEST["post"];
	$dept=$_REQUEST["department"];
	$q=$_REQUEST["qualification"];
	$s=$_REQUEST["salary"];
	$g=$_REQUEST["gender"];
	$a=$_REQUEST["address"];
if($e!="")
{
$e="Yes";
}
if($e=="")
{
$e="No";
}
	//name validation
	if($nm=="")
	{
		echo "<script> alert('Enter name')</script>";
		$count++;
	}
	elseif(!preg_match("/^[a-zA-Z ]*$/",$nm))
	{
		echo "<script> alert('only letters & space allowed in name field')</script>";
		$count++;
	}
	// email
	if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[_a-z0-9-]+)*(\.[a-z]{2,3})$",$em))
		{
			echo"<script> alert('Enter Proper Email....')</script>";
			$count++;	
		}
		// phone number
		if(!preg_match("/^[0-9]{10}$/",$ph))
	{
		echo "<script>alert('Enter Proper Number..')</script>";
		$count++;
	}
	// salary
	
	if(!preg_match("/^[0-9]*$/",$s))
	{
		echo "<script> alert('Only Numeric value allowed in salary field')</script>";
		$count++;
	}
	if($count==0)
	{
	$sql="insert into tbl_emp values('','$nm','$em','$ph','$post','$dept','$q','$s','$dob','$e','$g','$a')";
			mysqli_query($connection, $sql);
    echo "<script> alert('Employee Details Added Successfully.')</script>";
} else {
    //echo "Error: " . $sql . "<br>" . $connection->error;
}

		
    }
						?> 
						
<div class="footer"><center><br /><br />DEVELOPED BY <img src="images/sm.png" /> RAIYANI ANKITA</center></div>
</body>
</html>
