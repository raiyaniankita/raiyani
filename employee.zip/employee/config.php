<?php
$connection = mysqli_connect('localhost', 'root', '', 'db_emp');
?>