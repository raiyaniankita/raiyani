<?php
include("config.php");
$sql="select * from tbl_emp where emp_id=".$_REQUEST['epid'];
$result = mysqli_query($connection, $sql);
$row = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link type="text/css" href="style.css" rel="stylesheet" ></style>
<meta http-equiv="Content-Type" content="width=device-width, initial-scale=1" content="text/html; charset=utf-8" />
<script src="js/jquery.min.js"></script>
<script src="js/jquery-1.10.2.js"></script>
<script src="js/mjquery-ui.js"></script>
<script type="text/javascript" src="js/jquery.ptTimeSelect.js"></script>
<link rel="stylesheet" href="mjquery-ui.css">

<link rel="stylesheet" type="text/css" href="jquery.ptTimeSelect.css" />
<script type="text/javascript">
$(document).ready(function(){
	
	$('#cal').datepicker({ dateFormat: "yy-mm-dd" });

	
  	});			
 </script>
<title>Employee</title>
</head>
<body>
<div class="head"><a href="index.php" class="aa" >Add Employee</a>
<a href="view_emp.php" class="aa">View Employee</a></div>
<h2><center><br />Edit Employee</center></h2><br />

<form enctype="multipart/form-data" method="post">
  <div class="imgcontainer">
   
  </div>

  <div class="container">
    <label><b>Name</b></label>
    <input type="text" placeholder="Enter Employee name" name="name" value='<?php echo $row["emp_name"]; ?>' required>
    
	<label><b>Email</b></label>
    <input type="email" placeholder="Enter Email Address" name="email" value='<?php echo $row["emp_email"]; ?>' required>
    
    <label><b>Contact Number</b></label>
    <input type="text" placeholder="Enter Contact Number" name="phone" value='<?php echo $row["emp_contact"]; ?>' required>
    
    
    <label><b>Date Of Birth</b></label>
<input type="text" name="txt_cal" value='<?php echo $row["emp_dob"]; ?>' id="cal">
    
    <label><b>Post</b></label>
    <select name="post">
    <?php
	if($row["emp_post"]=="HOD")
	{
	?>
	<option value="HOD" selected="selected">HOD</option>
    <option value="PROFESSER">PROFESSER</option>
    <option value="ASSISTENT PROFESSER">ASSISTENT PROFESSER</option>
    <?php
	}
	if($row["emp_post"]=="PROFESSER")
	{
	?>
	<option value="HOD" >HOD</option>
    <option value="PROFESSER" selected="selected">PROFESSER</option>
    <option value="ASSISTENT PROFESSER">ASSISTENT PROFESSER</option>
    <?php
	}
	if($row["emp_post"]=="ASSISTENT PROFESSER")
	{
	?>
	<option value="HOD" >HOD</option>
    <option value="PROFESSER" >PROFESSER</option>
    <option value="ASSISTENT PROFESSER" selected="selected">ASSISTENT PROFESSER</option>
    <?php
	}
	
	?>
    </select>
    
    <label><b>Department</b></label>
    <select name="department">
    <?php
	if($row["emp_dept"]=="BCA")
	{
	?>
	<option value="BCA" selected="selected">BCA</option>
    <option value="BBA">BBA</option>
    <option value="MCA">MCA</option>
    <option value="MBA">MBA</option>
    <option value="MSC.IT.">MSC.IT.</option>
    <option value="PGDCA">PGDCA</option>
    <?php
	}
	if($row["emp_dept"]=="BBA")
	{
	?>
	<option value="BCA" >BCA</option>
    <option value="BBA" selected="selected">BBA</option>
    <option value="MCA">MCA</option>
    <option value="MBA">MBA</option>
    <option value="MSC.IT.">MSC.IT.</option>
    <option value="PGDCA">PGDCA</option>
    <?php
	}
	if($row["emp_dept"]=="MCA")
	{
	?>
	<option value="BCA" >BCA</option>
    <option value="BBA">BBA</option>
    <option value="MCA" selected="selected">MCA</option>
    <option value="MBA">MBA</option>
    <option value="MSC.IT.">MSC.IT.</option>
    <option value="PGDCA">PGDCA</option>
    <?php
	}
	if($row["emp_dept"]=="MBA")
	{
	?>
	<option value="BCA" >BCA</option>
    <option value="BBA">BBA</option>
    <option value="MCA">MCA</option>
    <option value="MBA" selected="selected">MBA</option>
    <option value="MSC.IT.">MSC.IT.</option>
    <option value="PGDCA">PGDCA</option>
    <?php
	}if($row["emp_dept"]=="MSC.IT.")
	{
	?>
	<option value="BCA">BCA</option>
    <option value="BBA">BBA</option>
    <option value="MCA">MCA</option>
    <option value="MBA">MBA</option>
    <option value="MSC.IT." selected="selected">MSC.IT.</option>
    <option value="PGDCA">PGDCA</option>
    <?php
	}if($row["emp_dept"]=="PGDCA")
	{
	?>
	<option value="BCA">BCA</option>
    <option value="BBA">BBA</option>
    <option value="MCA">MCA</option>
    <option value="MBA">MBA</option>
    <option value="MSC.IT.">MSC.IT.</option>
    <option value="PGDCA"  selected="selected">PGDCA</option>
    <?php
	}
	?>
    </select>
    
    <label><b>Qualification</b></label>
    <input type="text" placeholder="Enter Employee Qualification" name="qualification" value='<?php echo $row["emp_qualification"]; ?>' required>
    
    <label><b>Salary</b></label>
    <input type="text" placeholder="Enter Employee Salary" name="salary" value='<?php echo $row["emp_salary"]; ?>' required>
    
    <label><b>Gender</b></label><br />
    <?php
	if($row["emp_gender"]=="Female")
	  {
	  ?>
      <input type="radio" class="radio1" name="gender"  value="Female" checked="checked">Female<br />
      <input type="radio" name="gender" class="radio1"  value="Male">Male<br />
      <?php
	  }
	  if($row["emp_gender"]=="Male")
	  {
	  ?>
	  
      <input type="radio" class="radio1" name="gender"  value="Female">Female<br />
      <input type="radio" name="gender" class="radio1" checked="checked"  value="Male">Male<br />
      <?php
	  }
	  ?>
    </label>
    
    <label><b>Address</b></label>
    <textarea name="address" placeholder="Enter Adddress"> <?php echo $row["emp_address"]; ?> </textarea>
    
    <br /><label>
    <?php
	
    if($row["emp_experience"]=="Yes")
	  {
	  ?>
      <input type="checkbox" name="experience" checked="checked"> Experience
      <?php
	  }
	  else
	  {
	  ?>
	  <input type="checkbox" name="experience" > Experience
      <?php
	  }
	  ?>
    </label>
    
    
    <input type="submit" name="e_emp" value="Edit Employee Details">
</div>
</form>
  <?php
                                        $count=0;
if(isset($_POST['e_emp']))
{
	error_reporting(0);
	$i=$_REQUEST['epid'];
	
	$nm=$_REQUEST["name"];
	$em=$_REQUEST["email"];
	$ph=$_REQUEST["phone"];
	$dob=$_REQUEST["txt_cal"];
	$e=$_REQUEST["experience"];
	$post=$_REQUEST["post"];
	$dept=$_REQUEST["department"];
	$q=$_REQUEST["qualification"];
	$s=$_REQUEST["salary"];
	$g=$_REQUEST["gender"];
	$a=$_REQUEST["address"];
	
	if($e!="")
	{
	$e="Yes";
	}
	if($e=="")
	{
	$e="No";
	}
	//name validation
	if($nm=="")
	{
		echo "<script> alert('Enter name')</script>";
		$count++;
	}
	elseif(!preg_match("/^[a-zA-Z ]*$/",$nm))
	{
		echo "<script> alert('only letters & space allowed in name field')</script>";
		$count++;
	}
	// email
	if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[_a-z0-9-]+)*(\.[a-z]{2,3})$",$em))
		{
			echo"<script> alert('Enter Proper Email....')</script>";
			$count++;	
		}
	
		// phone number
		if(!preg_match("/^[0-9]{10}$/",$ph))
	{
		echo "<script>alert('Enter Proper Number..')</script>";
		$count++;
	}
	// salary
	
	if(!preg_match("/^[0-9]*$/",$s))
	{
		echo "<script> alert('Only Numeric value allowed in salary field')</script>";
		$count++;
	}
	if($count==0)
	{
	mysqli_query($connection,"UPDATE `tbl_emp` SET emp_name = '$nm' , emp_email = '$em', emp_contact = '$ph', emp_post = '$post', emp_dept = '$dept', emp_qualification = '$q', emp_salary = '$s', emp_dob = '$dob', emp_experience = '$e', emp_gender = '$g', emp_address = '$a'  WHERE emp_id = '$i'");

?>
                <script type="text/javascript">
                window.location.href="view_emp.php";
                </script>
        <?php	
}
}
?> 
</div>
<div class="footer"><center><br /><br />DEVELOPED BY <img src="images/sm.png" /> RAIYANI ANKITA</center></div>
</body>
</html>
