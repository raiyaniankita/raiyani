<?php
include("config.php");
?>
<?php
$sql="select * from tbl_emp";
			$result = mysqli_query($connection, $sql);
			


if(isset($_REQUEST['del']))
		{
			mysqli_query($connection,"delete from tbl_emp where emp_id=".$_REQUEST['del']);
			?>
                <script type="text/javascript">
                window.location.href="view_emp.php";
                </script>
        
<script type="text/javascript">
window.location.href="view_emp.php";
</script>	
		
<?php		
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link type="text/css" href="style.css" rel="stylesheet" ></style>
<meta http-equiv="Content-Type" content="width=device-width, initial-scale=1" content="text/html; charset=utf-8" />
<script src="js/jquery.min.js"></script>
<script src="js/jquery-1.10.2.js"></script>
<script src="js/mjquery-ui.js"></script>
<script type="text/javascript" src="js/jquery.ptTimeSelect.js"></script>
<link rel="stylesheet" href="mjquery-ui.css">

<link rel="stylesheet" type="text/css" href="jquery.ptTimeSelect.css" />
<script type="text/javascript">
$(document).ready(function(){
	
	$('#cal').datepicker({ dateFormat: "yy-mm-dd" });

	
  	});			
 </script>
<title>Employee</title>
</head>
<body>
<div class="head">
<a href="index.php" class="aa" >Add Employee</a>
<a href="view_emp.php" class="aa">View Employee</a>
</div>
<h2><center><br />View Employee</center></h2><br />
<div style="overflow-x:auto;">
  <table>
    <tr>
      <th>Name</th>
      <th>Email</th>
      <th>Contact</th>
      <th>Post</th>
      <th>Department</th>
      <th>Qualification</th>
      <th>Salary</th>
      <th>Date Of Birth</th>
      <th>Experience</th>
      <th>Gender</th>
      <th>Address</th>
      <th>Edit</th>
      <th>Delete</th>
    
    </tr>
  
  <?php 
			//$select=mysqli_query("select * from tbl_emp");
			
			$sql="select * from tbl_emp";
			$result = mysqli_query($connection, $sql);
			
			
			while($row=mysqli_fetch_assoc($result))
			{
		?>
		<tr>
            
            
			<td><?php echo $row['emp_name']; ?></td>
            <td><?php echo $row['emp_email']; ?></td>
            <td><?php echo $row['emp_contact']; ?></td>
             <td><?php echo $row['emp_post']; ?></td>
            <td><?php echo $row['emp_dept']; ?></td>
            <td><?php echo $row['emp_qualification']; ?></td>
            <td><?php echo $row['emp_salary']; ?></td>
            <td><?php echo $row['emp_dob']; ?></td>
            <td><?php echo $row['emp_experience']; ?></td>
            <td><?php echo $row['emp_gender']; ?></td>
            <td><?php echo $row['emp_address']; ?></td>
           
			<?php  echo"<td align='center'><a href='edit_emp.php?epid=$row[emp_id]'>"; ?>
    <img src="images/edit.png"  />
    <?php	  echo"<td align='center'><a href='view_emp.php?del=$row[emp_id]'>"; ?>
    <img src="images/delete.png"  />
   
		</tr>
		<?php
			}
		?>	
		
    
 </table>
 </div>
 

<div class="footer"><center><br /><br />DEVELOPED BY <img src="images/sm.png" /> RAIYANI ANKITA</center></div>
</body>
</html>
