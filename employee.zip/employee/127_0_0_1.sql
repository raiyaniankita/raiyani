-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 21, 2018 at 08:54 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 5.6.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_emp`
--
CREATE DATABASE IF NOT EXISTS `db_emp` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_emp`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_emp`
--

CREATE TABLE `tbl_emp` (
  `emp_id` int(11) NOT NULL,
  `emp_name` varchar(20) NOT NULL,
  `emp_email` varchar(30) NOT NULL,
  `emp_contact` bigint(10) NOT NULL,
  `emp_post` varchar(50) NOT NULL,
  `emp_dept` varchar(30) NOT NULL,
  `emp_qualification` varchar(50) NOT NULL,
  `emp_salary` int(10) NOT NULL,
  `emp_dob` varchar(10) NOT NULL,
  `emp_experience` varchar(50) NOT NULL,
  `emp_gender` varchar(10) NOT NULL,
  `emp_address` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_emp`
--

INSERT INTO `tbl_emp` (`emp_id`, `emp_name`, `emp_email`, `emp_contact`, `emp_post`, `emp_dept`, `emp_qualification`, `emp_salary`, `emp_dob`, `emp_experience`, `emp_gender`, `emp_address`) VALUES
(9, 'ankita', 'a@gmail.com', 8956123657, 'PROFESSER', 'MSC.IT.', 'mscit', 50000, '2017-08-01', 'yes', 'Female', 'rajkot'),
(10, 'bhavika', 'b@gmail.com', 7845127845, 'ASSISTENT PROFESSER', 'MBA', 'bba', 45000, '2017-04-01', 'yes', 'Female', 'gandhinagar'),
(11, 'rutu', 'rutu@gmail.com', 7845963258, 'HOD', 'PGDCA', 'bca', 30000, '2017-02-05', 'yes', 'Female', 'rajkot'),
(12, 'ekta', 'e@yahoo.com', 9874178965, 'ASSISTENT PROFESSER', 'BCA', 'mscit', 40000, '2018-08-05', 'yes', 'Female', 'surat');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_emp`
--
ALTER TABLE `tbl_emp`
  ADD PRIMARY KEY (`emp_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_emp`
--
ALTER TABLE `tbl_emp`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
